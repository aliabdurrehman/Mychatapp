import 'package:chatapp/components/my_text_field.dart';
import 'package:chatapp/services/chat/chat_services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ChatPage extends StatefulWidget {
  final String receiverUserEmail;
   final String receiverUserID;

  const ChatPage({
    super.key,
    required this.receiverUserEmail,
    required this.receiverUserID,
    });

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ChatService _chatService = ChatService();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  void sendMessage() async{

    if(_messageController.text.isNotEmpty){
      await _chatService.sendMessage(widget.receiverUserID, _messageController.text);

      _messageController.clear();


    }
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.receiverUserEmail),),
      body: Column(
        children: [
          //message
          Expanded(child: _buildMessageList(),
          ),
          // user input 
          _buildMessageInput(),
        ],
      ),
      );
  }

  // build message list
  Widget _buildMessageList(){
    return StreamBuilder(
      stream: _chatService.getMessages(
      widget.receiverUserID, _firebaseAuth.currentUser!.uid),
       builder: (context , snapshot){
       if(snapshot.hasError){
        return Text('Error${snapshot.error}');
       }
       if(snapshot.connectionState== ConnectionState.waiting){
        return const Text('loading...');
       }

       return ListView();



       },
       
       
       );
  }



  //build mesaage item
//build mesage input
  Widget _buildMessageInput(){
    return Row(
      children: [
        //textfield
        Expanded(
          child: MyTextfield(hintText: 'Enter Message',
           obscureText: false,
            controller: _messageController,
            ),
            ),

            //send button
            IconButton(
              onPressed: sendMessage,
             icon: const Icon(
              Icons.arrow_upward,
              size: 40,
              ),
             )
      
      
      
      
      
      
      
      
      
      
      ],);



  }




}